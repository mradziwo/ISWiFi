#include "regs.h"
#include "version.h"
#include <string.h>

static U16 ServiceReg;
static tRegs Regs;
static tMode Mode;

tMode GetMode(void)
	{
	return Mode;
	};

void SetMode(tMode mode)
	{
	if(mode<=FactoryMode && Regs.Phase==Stop)
		Mode=mode;
	};

void RegSetDefault(void)
	{
	memset(&Regs,0,sizeof(Regs));
	Regs.FirmwareVer=(VER_MAJOR<<8)|VER_MINOR;
	Regs.FirmwareRev=(VER_MODS<<15)|VER_SVN;
	};

tRegs* GetRegs(void)
	{
	return &Regs;
	};

U8 RegAddrValidation(U16 addr)
	{
	return !!((addr<sizeof(tRegs)/sizeof(U16)) || addr==REG_ADDR_SERVICE);
	};

static U8 RegWriteAccess(U16 addr)
	{
	switch(Mode)
		{
		case FactoryMode:
			switch(addr)
				{
				case REG_ADDR(HardwareVer):
				case REG_ADDR(Id):
					return true;
				}
		case ServiceMode:
			switch(addr)
				{
				case REG_ADDR(PWMmin):
				case REG_ADDR(PWMmax):
				case REG_ADDR(PWMstart):
				case REG_ADDR(Nmax):
				case REG_ADDR(Fan):
				case REG_ADDR(Alarm):
				case REG_ADDR(ClearFail):
				case REG_ADDR(DKGPowerSupply):
				case REG_ADDR(PWM):
					return true;
				}
		case NormalMode:
			switch(addr)
				{
				case REG_ADDR(ModbusAddr):
				case REG_ADDR(RS485Baudrate):
				case REG_ADDR(UtcTimeL):
				case REG_ADDR(UtcTimeH):
				case REG_ADDR(UtcOffset):
				case REG_ADDR(PowerSource):
				case REG_ADDR(FailNo):
				case REG_ADDR(Reg_0):
					return true;
				case REG_ADDR(PowerRequest):
					{
					if(Regs.PowerSource==RS485)
						return true;
					}

				}
		}
	return false;
	};

U8 RegWrite(U16 addr, U16 data)
	{
	if(addr==REG_ADDR_SERVICE)
		{
		ServiceReg=data;
		return ServiceEvent(data);
		}
	else
		{
		if(!RegAddrValidation(addr))
			return 1;
		if(!RegWriteAccess(addr))
			return 2;
		return RegWriteEvent(addr,data);
		}
	};
	
U8 RegRead(U16 addr, U16* data)
	{
	if(data==NULL) return 1;
	if(addr==REG_ADDR_SERVICE)
		*data=ServiceReg;
	else
		{
		if(!RegAddrValidation(addr))
			return 2;
		return RegReadEvent(addr,data);
		}
	return 0;
	};

__weak U8 ServiceEvent(U16 data) { return 0; }
__weak U8 RegWriteEvent(U16 addr, U16 data) { Regs.Address[addr]=data; return 0; }
__weak U8 RegReadEvent(U16 addr, U16* data) { *data=Regs.Address[addr];return 0; }
