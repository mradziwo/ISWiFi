#include "app.h"
#include "m24512.h"


//static U8 RamDisk[M24512_BLK_SIZ*M24512_BLK_NBR];
extern I2C_HandleTypeDef hi2c1;

static U32 Timeout=10;
static U8 ChipAddr=(0x50<<1);


U8 M24512_Init(U8 lun)
    {
    return 0;
    };

U8 M24512_GetCapacity(U8 lun, U32* block_num, U16* block_size)
    {
    assert_param(block_num);
    assert_param(block_size);
    *block_num =M24512_BLK_NBR;
    *block_size=M24512_BLK_SIZ;
    return 0;
    };

U8 M24512_IsReady(U8 lun)
    {
    return 0;
    };

U8 M24512_IsWriteProtected(U8 lun)
    {
	return AppPowerFail();
    };

U8 M24512_Read(U8 lun, U8* buf, U32 blk_addr, U16 blk_len)
    {
    if (blk_addr+blk_len>M24512_BLK_NBR)
	return 1;
    //memcpy(buf,&RamDisk[blk_addr*M24512_BLK_SIZ],blk_len*M24512_BLK_SIZ);
    HAL_StatusTypeDef status=HAL_OK;
    U32 size=blk_len *M24512_BLK_SIZ;
    U32 addr=blk_addr*M24512_BLK_SIZ;
    while(size>0)
		{
		U32 len=128;
		if(len>size) len=size;
		U32 tick=HAL_GetTick();
		while((status=HAL_I2C_Mem_Read(&hi2c1,ChipAddr,addr,I2C_MEMADD_SIZE_16BIT,buf,len,Timeout))!=HAL_OK && HAL_GetTick()-tick<Timeout);
		if(status!=HAL_OK) break;
		size-=len;
		buf +=len;
		addr+=len;
		}
    return (status!=HAL_OK);
    };

U8 M24512_Write(U8 lun, U8* buf, U32 blk_addr, U16 blk_len)
    {
    if(blk_addr+blk_len>M24512_BLK_NBR)
	return 1;
    //memcpy(&RamDisk[blk_addr*M24512_BLK_SIZ],buf,blk_len*M24512_BLK_SIZ);
    HAL_StatusTypeDef status=HAL_OK;
    U32 size=blk_len *M24512_BLK_SIZ;
    U32 addr=blk_addr*M24512_BLK_SIZ;
    while(size>0)
		{
		U32 len=128;
		if(len>size) len=size;
		U32 tick=HAL_GetTick();
		while((status=HAL_I2C_Mem_Write(&hi2c1,ChipAddr,addr,I2C_MEMADD_SIZE_16BIT,buf,len,Timeout))!=HAL_OK && HAL_GetTick()-tick<Timeout);
		if(status!=HAL_OK) break;
		size-=len;
		buf +=len;
		addr+=len;
		}
    return (status!=HAL_OK);
    };

U8 M24512_GetMaxLun(void)
    {
    return 0; // index
    };
