#include "app.h"
#include "cmsis_os.h"
#include "fatfs.h"
#include "usb_device.h"
#include "vcp.h"
#include "m24512.h"
#include "rtc.h"
#include "led.h"
#include "filter.h"
#include "modbus.h"
#include "regs.h"
#include "xml.h"
#include "rpm.h"

extern RTC_HandleTypeDef hrtc;
extern ADC_HandleTypeDef hadc1;

static tGpioFilter PowerGood;
static U8 BackupValid;
static tResetFlag ResetFlag;
static U32 ResetNo;

static tXmlEntry HardwareVer;
static tXmlEntry Id;
static tXmlEntry ModbusAddr;
static tXmlEntry RS485Baudrate;
static tXmlEntry PowerSource;
static tXmlEntry Tpf;
static tXmlEntry Tss;
static tXmlEntry Tfce;
static tXmlEntry Tpi;
static tXmlEntry Tlr;
static tXmlEntry Tign;
static tXmlEntry Tpef;
static tXmlEntry Tpsf;
static tXmlEntry Tmr;
static tXmlEntry Tmrd;
static tXmlEntry Tfl;
static tXmlEntry Fmin;
static tXmlEntry Nmax;
static tXmlEntry PWMstart;
static tXmlEntry PWMmin;
static tXmlEntry PWMmax;


static void BackupInit(void)
	{
	ResetFlag.u8=0;
	ResetFlag.Pin   =(__HAL_RCC_GET_FLAG(RCC_FLAG_PINRST) !=RESET);
	ResetFlag.Por   =(__HAL_RCC_GET_FLAG(RCC_FLAG_PORRST) !=RESET);
	ResetFlag.Soft  =(__HAL_RCC_GET_FLAG(RCC_FLAG_SFTRST) !=RESET);
	ResetFlag.IWdg  =(__HAL_RCC_GET_FLAG(RCC_FLAG_IWDGRST)!=RESET);
	ResetFlag.WWdg  =(__HAL_RCC_GET_FLAG(RCC_FLAG_WWDGRST)!=RESET);
	ResetFlag.LowPwr=(__HAL_RCC_GET_FLAG(RCC_FLAG_LPWRRST)!=RESET);
	__HAL_RCC_CLEAR_RESET_FLAGS();

	RTCTIME rtc;
	rtc_gettime(&rtc);

	if(HAL_RTCEx_BKUPRead(&hrtc,RTC_BKP_DR1)==0x32F2)
		BackupValid=true;
	else
		{
		if(rtc.year<2000)
			{
			rtc.year =2000;
			rtc.month=1;
			rtc.mday =1;
			rtc.hour =0;
			rtc.min  =0;
			rtc.sec  =0;
			rtc_settime(&rtc);
			rtc_gettime(&rtc);
			}
		HAL_RTCEx_BKUPWrite(&hrtc,RTC_BKP_DR1,0x32F2);
		BackupValid=false;
		}

	ResetNo=((U32)HAL_RTCEx_BKUPRead(&hrtc,RTC_BKP_DR3)<<16) | HAL_RTCEx_BKUPRead(&hrtc,RTC_BKP_DR2);
	ResetNo++;
	HAL_RTCEx_BKUPWrite(&hrtc,RTC_BKP_DR3,ResetNo>>16);
	HAL_RTCEx_BKUPWrite(&hrtc,RTC_BKP_DR2,ResetNo&0xFFFF);
	};

U8 AppBackupValid(void)
	{
	return !!BackupValid;
	};

U8 AppPowerFail(void)
	{
	return !GpioFilterIsActive(&PowerGood);
	};

void AppTimer(void)
	{
	GpioFilterProcess(&PowerGood,1);
	};

U8 AppUsbConnected(void)
	{
	return !!(hUsbDeviceFS.dev_state==USBD_STATE_CONFIGURED);
	};

U8 ServiceEvent(U16 data)
	{
	extern U32 __noinit_start__;
	U32* key=(U32*)&__noinit_start__;

	if(data==0x1111)
		SetMode(ServiceMode);
	else if(data==0x2222)
		SetMode(FactoryMode);
	else if(data==0x3333) // reset
		NVIC_SystemReset();
	else if(data==0x4444) // boot
		{
		if(GetMode()==NormalMode) return 1;
		key[0]=0xABBACAFE;
		NVIC_SystemReset();
		}
	else if(data==0x5555) // usb msc
		{
		if(GetMode()==NormalMode) return 1;
		key[1]=0xABBACAFE;
		NVIC_SystemReset();
		}
	else
		SetMode(NormalMode);
	return 0;
	};

U8 RegWriteEvent(U16 addr, U16 data)
	{
	char* tokens=NULL;
	if(addr==REG_ADDR(UtcTimeH))
		{
		GetRegs()->UtcTimeH=data;
		U32 utc=((U32)GetRegs()->UtcTimeH<<16)|GetRegs()->UtcTimeL;
		return !rtc_setutc(utc);
		}
	else if(addr==REG_ADDR(HardwareVer))
		{
		if(GetRegs()->HardwareVer!=0 || data==0)
			return 1;
		tokens="config\0registers\0HardwareVer\0value";
		}
	else if(addr==REG_ADDR(Id))
		{
		if(GetRegs()->Id!=0 || data==0)
			return 1;
		tokens="config\0registers\0Id\0value";
		}
	else if(addr==REG_ADDR(ModbusAddr))
		{
		if(GetRegs()->ModbusAddr==data)
			return 0;
		if(!(ModbusAddr.min<=data && data<=ModbusAddr.max))
			return 1;
		tokens="config\0registers\0ModbusAddr\0value";
		}
	else if(addr==REG_ADDR(RS485Baudrate))
		{
		if(GetRegs()->RS485Baudrate==data)
			return 0;
		if(!(RS485Baudrate.min<=data && data<=RS485Baudrate.max))
			return 1;
		tokens="config\0registers\0RS485Baudrate\0value";
		}
	else if(addr==REG_ADDR(PowerSource))
		{
		if(GetRegs()->PowerSource==data)
			return 0;
		if(!(PowerSource.min<=data && data<=PowerSource.max))
			return 1;
		tokens="config\0registers\0PowerSource\0value";
		}
	else if(addr==REG_ADDR(PWMmin))
		{
		if(GetRegs()->PWMmin==data)
			return 0;
		if(!(PWMmin.min<=data && data<=PWMmin.max))
			return 1;
		if(!(PWMmin.value<=PWMstart.value && PWMstart.value<=PWMmax.value))
			return 2;
		tokens="config\0registers\0PWMmin\0value";
		}
	else if(addr==REG_ADDR(PWMmax))
		{
		if(GetRegs()->PWMmax==data)
			return 0;
		if(!(PWMmax.min<=data && data<=PWMmax.max))
			return 1;
		if(!(PWMmin.value<=PWMstart.value && PWMstart.value<=PWMmax.value))
			return 2;
		tokens="config\0registers\0PWMmax\0value";
		}
	else if(addr==REG_ADDR(PWMstart))
		{
		if(GetRegs()->PWMstart==data)
			return 0;
		if(!(PWMstart.min<=data && data<=PWMstart.max))
			return 1;
		if(!(PWMmin.value<=PWMstart.value && PWMstart.value<=PWMmax.value))
			return 2;
		tokens="config\0registers\0PWMstart\0value";
		}
	else if(addr==REG_ADDR(Nmax))
		{
		if(GetRegs()->Nmax==data)
			return 0;
		if(!(Nmax.min<=data && data<=Nmax.max))
			return 1;
		tokens="config\0registers\0Nmax\0value";
		}
	else if(addr==REG_ADDR(FailNo))
		{
		if(data!=0)
			return 1;
		}
		
	if(tokens)
		{
		tXml* xml=NULL;
		if(XmlInit(&xml,_T("0:/config.xml"),4096) && XmlInit(&xml,_T("0:/config.old"),4096))
			return 2;
		U8 save=!XmlWrite(xml,_T("0:/config.new"),tokens,4,data,"%hu");
		XmlClose(&xml);
		if(!save) return 3;
		f_rename(_T("0:/config.xml"),_T("0:/config.old"));
		f_rename(_T("0:/config.new"),_T("0:/config.xml"));
		f_unlink(_T("0:/config.old"));
		}
		
	GetRegs()->Address[addr]=data;
	return 0;
	};

U8 RegReadEvent(U16 addr, U16* data)
	{
	if(addr==REG_ADDR(UtcTimeL))
		{
		U32 utc;
		if(!rtc_getutc(&utc))
			return 1;
		GetRegs()->UtcTimeL=utc&0xFFFF;
		GetRegs()->UtcTimeH=(utc>>16)&0xFFFF;
		}
	*data=GetRegs()->Address[addr];
	return 0;
	};

U8 ReadConfig(void)
	{
	tXml* xml=NULL;
	if(XmlInit(&xml,_T("0:/config.xml"),4096) && XmlInit(&xml,_T("0:/config.old"),4096))
		return 1;
	
	if(XmlReadEntry(xml,&HardwareVer,"config\0registers\0HardwareVer",3))
		return 2;
	GetRegs()->HardwareVer=HardwareVer.value;
			
	XmlReset(xml);
	if(XmlReadEntry(xml,&Id,"config\0registers\0Id",3))
		return 3;
	GetRegs()->Id=Id.value;

	XmlReset(xml);
	if(XmlReadEntry(xml,&ModbusAddr,"config\0registers\0ModbusAddr",3))
		return 4;
	GetRegs()->ModbusAddr=ModbusAddr.value;

	XmlReset(xml);
	if(XmlReadEntry(xml,&RS485Baudrate,"config\0registers\0RS485Baudrate",3))
		return 5;
	GetRegs()->RS485Baudrate=RS485Baudrate.value;

	XmlReset(xml);
	if(XmlReadEntry(xml,&PowerSource,"config\0registers\0PowerSource",3))
		return 6;
	GetRegs()->PowerSource=PowerSource.value;
	
	XmlReset(xml);
	if(XmlReadEntry(xml,&Tpf,"config\0constants\0Tpf",3))
		return 7;

	XmlReset(xml);
	if(XmlReadEntry(xml,&Tss,"config\0constants\0Tss",3))
		return 8;
	
	XmlReset(xml);
	if(XmlReadEntry(xml,&Tfce,"config\0constants\0Tfce",3))
		return 9;

	XmlReset(xml);
	if(XmlReadEntry(xml,&Tpi,"config\0constants\0Tpi",3))
		return 10;

	XmlReset(xml);
	if(XmlReadEntry(xml,&Tlr,"config\0constants\0Tlr",3))
		return 11;
	
	XmlReset(xml);
	if(XmlReadEntry(xml,&Tign,"config\0constants\0Tign",3))
		return 12;

	XmlReset(xml);
	if(XmlReadEntry(xml,&Tpef,"config\0constants\0Tpef",3))
		return 13;

	XmlReset(xml);
	if(XmlReadEntry(xml,&Tpsf,"config\0constants\0Tpsf",3))
		return 14;

	XmlReset(xml);
	if(XmlReadEntry(xml,&Tmr,"config\0constants\0Tmr",3))
		return 15;

	XmlReset(xml);
	if(XmlReadEntry(xml,&Tmrd,"config\0constants\0Tmrd",3))
		return 15;

	XmlReset(xml);
	if(XmlReadEntry(xml,&Tfl,"config\0constants\0Tfl",3))
		return 16;

	XmlReset(xml);
	if(XmlReadEntry(xml,&Fmin,"config\0constants\0Fmin",3))
		return 17;
	
	XmlReset(xml);
	if(XmlReadEntry(xml,&Nmax,"config\0registers\0Nmax",3))
		return 18;
	GetRegs()->Nmax=Nmax.value;

	XmlReset(xml);
	if(XmlReadEntry(xml,&PWMstart,"config\0registers\0PWMstart",3))
		return 19;
	GetRegs()->PWMstart=PWMstart.value;
	
	XmlReset(xml);
	if(XmlReadEntry(xml,&PWMmin,"config\0registers\0PWMmin",3))
		return 20;
	GetRegs()->PWMmin=PWMmin.value;

	XmlReset(xml);
	if(XmlReadEntry(xml,&PWMmax,"config\0registers\0PWMmax",3))
		return 21;
	GetRegs()->PWMmax=PWMmax.value;

	//if(!(PWMmin.value<=PWMstart.value && PWMstart.value<=PWMmax.value))
	//	return 22;

	XmlClose(&xml);
	return 0;
	};
	
static S16 GetAnalogInput(void)
	{
	ADC_ChannelConfTypeDef sConfig;
	sConfig.Rank = 1;
	sConfig.SamplingTime = ADC_SAMPLETIME_28CYCLES_5;
	sConfig.Channel = ADC_CHANNEL_14;
	HAL_ADC_ConfigChannel(&hadc1, &sConfig);
	HAL_ADC_Start(&hadc1);
	HAL_ADC_PollForConversion(&hadc1,1);
	return HAL_ADC_GetValue(&hadc1);
	};

static S16 GetAnalogTemperature(void)
	{
	ADC_ChannelConfTypeDef sConfig;
	sConfig.Rank = 1;
	sConfig.SamplingTime = ADC_SAMPLETIME_28CYCLES_5;
	sConfig.Channel = ADC_CHANNEL_15;
	HAL_ADC_ConfigChannel(&hadc1, &sConfig);
	HAL_ADC_Start(&hadc1);
	HAL_ADC_PollForConversion(&hadc1,1);
	return HAL_ADC_GetValue(&hadc1);
	};


static FRESULT Logging(const TCHAR* dir_path, char* data, UINT len)
	{
	FRESULT fr=FR_OK;
	FATFS* fs;
	DWORD nclst;
	DIR dir;
	FILINFO finfo;
	TCHAR lfname[_MAX_LFN+1];
	finfo.lfname=lfname;
	finfo.lfsize=ARRAY_SIZE(lfname);
	TCHAR path[_MAX_LFN+1];
	
	RTCTIME rtc;
	rtc_gettime(&rtc);

	// clean old log files
	while(f_getfree(dir_path,&nclst,&fs)==FR_OK && nclst*100/(fs->n_fatent-2)<10) // % of disk capacity
		{
		// find the oldest file
		U32 oldest=~0;
		fr=f_findfirst(&dir,&finfo,dir_path,"*.log");
		while(fr==FR_OK && finfo.fname[0])
			{
			U32 date=~0;
			if(sscanf(finfo.fname,"%lu",&date)==1)
				{
				if(oldest>date)
					oldest=date;
				}
			fr=f_findnext(&dir,&finfo);
			}
		f_closedir(&dir);
		// and remove it
		if(oldest==~0)
			break;
		snprintf(path, sizeof(path), "%s/%lu.log", dir_path, oldest);
		if(f_unlink(path)!=FR_OK)
			break;
		}

	if(f_stat(dir_path,&finfo)==FR_NO_FILE)
		f_mkdir(dir_path);

	// open a new file
	snprintf(path, sizeof(path), "%s/%i%02i%02i.log", dir_path, rtc.year, rtc.month, rtc.mday);
	FIL file;
	if((fr=f_open(&file,path,FA_WRITE|FA_OPEN_ALWAYS))==FR_OK)
		{
		if((fr=f_lseek(&file,f_size(&file)))==FR_OK)
			{
			UINT bw,n=snprintf(path, sizeof(path), "%i-%02i-%02i %02i:%02i:%02i\n", rtc.year, rtc.month, rtc.mday, rtc.hour, rtc.min, rtc.sec);
			n=MIN(sizeof(path),n);
			if((fr=f_write(&file,path,n,&bw))!=FR_OK || bw<n)
				fr=100;
			else if((fr=f_write(&file,data,len,&bw))!=FR_OK || bw<len)
				fr=100;
			}
		f_close(&file);
		}
	return fr;
	};


void StartDefaultTask(void const * argument)
	{
	IWDG_HandleTypeDef iwdg;
	iwdg.Instance=IWDG;
	iwdg.Init.Prescaler=IWDG_PRESCALER_256; // LSI is ~40kHz
	iwdg.Init.Reload=2*40000/256; // 0-0xFFF, max 26.2s
	if(iwdg.Init.Reload>0xFFF) iwdg.Init.Reload=0xFFF;
	HAL_IWDG_Init(&iwdg);
	HAL_IWDG_Start(&iwdg);
	
	GpioFilterInit(&PowerGood,GPIOE,GPIO_PIN_0,GpioFilterBistable,GpioActiveLow,10); // todo next version will have a dedicated input

	BackupInit();
	osDelay(50); // wait for PowerGood signal

	MX_FATFS_Init();
	FATFS FatFs;
	FATFS* fs;
	char buf[256];
	U8 usb_msc=false;

//	M24512_Write(0,(uint8_t*)buf,0,1); // destroy FAT

	const TCHAR* log_path=_T("0:/log");
	const TCHAR* path=_T("0:");
	if(f_mount(&FatFs,path,0)==FR_OK)
		{
		DWORD nclst;
		if(f_getfree(path,&nclst,&fs)==FR_NO_FILESYSTEM)
			{
			usb_msc=true;
			if(f_mkfs(path,1,0)==FR_OK)
				f_getfree(path,&nclst,&fs);
			}
		}
	
	RegSetDefault();
	U8 config_err=ReadConfig(); // consider checking after every write?
	//if(config_err)
	//	usb_msc=true;
	
	extern U32 __noinit_start__;
	U32* key=(U32*)&__noinit_start__;
	if(key[1]==0xABBACAFE)
		usb_msc=true;
	key[1]=0;

	osThreadDef(ModbusSerialTask, ModbusSerialTask, osPriorityNormal, 0, 1024);
	osThreadDef(VcpTask, VcpTask, osPriorityNormal, 0, 1024);
	if(!usb_msc)
		{
		osThreadCreate(osThread(ModbusSerialTask), NULL);
		osThreadCreate(osThread(VcpTask), NULL);
		}
	MX_USB_DEVICE_Init(usb_msc);

	tGpioOutput Fan;
	tGpioOutput Alarm;
	tGpioOutput ClearFail;
	tGpioOutput DKGPowerSupply;
	GpioOutputInit(&Fan           ,GPIOE,GPIO_PIN_15,GpioActiveHigh);
	GpioOutputInit(&Alarm         ,GPIOE,GPIO_PIN_12,GpioActiveHigh);
	GpioOutputInit(&ClearFail     ,GPIOE,GPIO_PIN_13,GpioActiveHigh);
	GpioOutputInit(&DKGPowerSupply,GPIOE,GPIO_PIN_14,GpioActiveHigh);

	tGpioFilter ContactInput;
	tGpioFilter ContactDrv1;
	tGpioFilter ContactDrv2;
	tGpioFilter ContactStart;
	tGpioFilter PowerSupply;
	tGpioFilter IgnitionTrafo;
	tGpioFilter AuxBlower;
	tGpioFilter SolenoidValve1;
	tGpioFilter SolenoidValve2;
	tGpioFilter BurnerFail;
	GpioFilterInit(&ContactInput  ,GPIOD,GPIO_PIN_10,GpioFilterBistable,GpioActiveLow ,500);
	GpioFilterInit(&ContactDrv1   ,GPIOB,GPIO_PIN_0 ,GpioFilterBistable,GpioActiveLow ,500);
	GpioFilterInit(&ContactDrv2   ,GPIOB,GPIO_PIN_1 ,GpioFilterBistable,GpioActiveLow ,500);
	GpioFilterInit(&ContactStart  ,GPIOD,GPIO_PIN_13,GpioFilterBistable,GpioActiveLow ,500);
	GpioFilterInit(&PowerSupply   ,GPIOE,GPIO_PIN_0 ,GpioFilterBistable,GpioActiveLow ,500);
	GpioFilterInit(&IgnitionTrafo ,GPIOE,GPIO_PIN_1 ,GpioFilterBistable,GpioActiveLow ,500);
	GpioFilterInit(&AuxBlower     ,GPIOE,GPIO_PIN_2 ,GpioFilterBistable,GpioActiveLow ,500);
	GpioFilterInit(&SolenoidValve1,GPIOE,GPIO_PIN_3 ,GpioFilterBistable,GpioActiveLow ,500);
	GpioFilterInit(&SolenoidValve2,GPIOE,GPIO_PIN_4 ,GpioFilterBistable,GpioActiveLow ,500);
	GpioFilterInit(&BurnerFail    ,GPIOE,GPIO_PIN_5 ,GpioFilterBistable,GpioActiveLow ,500);

	tLowPassFIR AnalogInput;
	S16 AnalogInputBuf[20];
	LowPassFIRInit(&AnalogInput,AnalogInputBuf,ARRAY_SIZE(AnalogInputBuf));

	tLowPassFIR AnalogTemp;
	S16 AnalogTempBuf[20];
	LowPassFIRInit(&AnalogTemp,AnalogTempBuf,ARRAY_SIZE(AnalogTempBuf));

	tLowPassFIR Rpm;
	S16 RpmBuf[10];
	LowPassFIRInit(&Rpm,RpmBuf,ARRAY_SIZE(RpmBuf));

	const U32 dt=10;
	U32 t=osKernelSysTick();
	U32 t_rpm=t;
	U32 t_contact=t;
	U32 timer=0;
	U16 power_source=GetRegs()->PowerSource;
	U8  noise_immunity=false;
	U8  pre_operation=true;
	GetRegs()->FailNo=0;

	U16 fan_target=0;
	U16 fan_set=0;
	U32 t_fan=t;

	U8 StartCondition(void)
		{
		return !config_err && !!(PWMmin.value<=PWMstart.value && PWMstart.value<=PWMmax.value);
		};

	void SetFan(U16 value)
		{
		fan_target=value;
		};

	U16 FanProcess(void)
		{
		U16 value=fan_target;
		if(value==0)
			t_fan=t;
		else if(t-t_fan<(U32)Tss.value*1000)
			{
			if(value<PWMstart.value)
				value=PWMstart.value;
			}
		else
			{
			U32 dv=0;
			U32 dt=t-t_fan-(U32)Tss.value*1000;
			U16 v=TIM3->CCR1;
			U32 tmr=(U32)((v<=value)?Tmr.value:Tmrd.value)*1000;
			if(tmr==0)
				t_fan+=dt;
			else if((dv=dt*(PWMmax.value-PWMmin.value)/tmr)==0)
				value=v;
			else
				{
				if(v<value)
					{
					if((v+=dv)>value)
						v=value;
					}
				else if(v>value)
					{
					if((v-=dv)<value)
						v=value;
					}
				value=v;
				t_fan+=dt;
				}
			}
		GpioOutputSet(&Fan,!!(value>0));
		TIM3->CCR1=value;
		return value;
		};

	while(1)
		{
		HAL_IWDG_Refresh(&iwdg);
		osDelayUntil(&t,dt);

		GetRegs()->SolenoidValve1=GpioFilterProcess(&SolenoidValve1,dt);

		if(noise_immunity==false)
			{
			GetRegs()->ContactInput  =GpioFilterProcess(&ContactInput  ,dt);
			GetRegs()->ContactDrv1   =GpioFilterProcess(&ContactDrv1   ,dt);
			GetRegs()->ContactDrv2   =GpioFilterProcess(&ContactDrv2   ,dt);
			GetRegs()->ContactStart  =GpioFilterProcess(&ContactStart  ,dt);
			GetRegs()->PowerSupply   =GpioFilterProcess(&PowerSupply   ,dt);
			GetRegs()->IgnitionTrafo =GpioFilterProcess(&IgnitionTrafo ,dt);
			GetRegs()->AuxBlower     =GpioFilterProcess(&AuxBlower     ,dt);
			//GetRegs()->SolenoidValve1=GpioFilterProcess(&SolenoidValve1,dt);
			GetRegs()->SolenoidValve2=GpioFilterProcess(&SolenoidValve2,dt);
			GetRegs()->BurnerFail    =GpioFilterProcess(&BurnerFail    ,dt);
			GetRegs()->PowerFail     =AppPowerFail();

			S16 adu=GetAnalogInput();
			LowPassFIRProcess(&AnalogInput,adu);
			adu=LowPassFIRValue(&AnalogInput);
			S16 mv=((S32)adu*2048)>>12;
			GetRegs()->AnalogInput=mv*5; // PC4 (factor 5)

			adu=GetAnalogTemperature();
			LowPassFIRProcess(&AnalogTemp,adu);
			adu=LowPassFIRValue(&AnalogTemp);
			mv=((S32)adu*2048)>>12;
			GetRegs()->AnalogTemp=(mv-500); // PC5 (10 mV/deg.C, 0 deg.C @ 500mV)

			if(t-t_rpm>=1000)
				{
				t_rpm=t;
				U32 rpm=GetRevolutionFreq()/2; // two impulses per revolution
				if(rpm>32767) rpm=32767;
				LowPassFIRProcess(&Rpm,rpm);
				rpm=LowPassFIRValue(&Rpm);
				GetRegs()->Tacho=rpm;
				}
			}

		DisplayRefresh(t);
		if(timer>=dt) timer-=dt;
		else timer=0;

		switch(GetRegs()->Phase)
			{
			default:
			case Stop:
				{
				// latching power source, change is possible only in Stop phase
				if(power_source!=GetRegs()->PowerSource)
					{
					power_source=GetRegs()->PowerSource;
					GetRegs()->PowerRequest=0;
					}

				noise_immunity=false;
				pre_operation=true;
				t_fan=t;

				if(GetMode()!=NormalMode)
					{
					GpioOutputSet(&Fan,           !!GetRegs()->Fan);
					GpioOutputSet(&Alarm,         !!GetRegs()->Alarm);
					GpioOutputSet(&ClearFail,     !!GetRegs()->ClearFail);
					GpioOutputSet(&DKGPowerSupply,!!GetRegs()->DKGPowerSupply);
					TIM3->CCR1=fan_set=GetRegs()->PWM;
					}
				else
					{
					SetFan(0);
					GpioOutputSet(&Fan,false);
					GpioOutputSet(&Alarm,false);
					GpioOutputSet(&ClearFail,false);
					GpioOutputSet(&DKGPowerSupply,false);
					TIM3->CCR1=fan_set=0;
					}

				if(!usb_msc && (((power_source==Analog || power_source==Contact) && GetRegs()->ContactStart) || \
					(power_source==RS485 && GetRegs()->PowerRequest>0)))
					{
					if(!StartCondition())
						{
						timer=(U32)Tfl.value*1000;
						GetRegs()->Phase=Failure;
						Logging(log_path,buf,snprintf(buf,sizeof(buf),"Phase(0x%02X)\n",GetRegs()->Phase));
						}
					else
						{
						// GetRegs()->FailNo=0; // neverending start
						SetFan(1000);
						timer=(U32)Tpf.value*1000;
						GetRegs()->Phase=PreFlush;
						Logging(log_path,buf,snprintf(buf,sizeof(buf),"Phase(0x%02X), PowerSource(%hu)\n",GetRegs()->Phase,power_source));
						}
					}
				break;
				}
			case Failure:
				{
				if(timer<=0)
					{
					GetRegs()->Phase=Stop;
					GetRegs()->PowerRequest=0;
					}
				break;
				}

			case PreFlush:
				{
				if(timer<=0)
					{
					SetFan(PWMstart.value);
					timer=(U32)Tss.value*1000;
					GetRegs()->Phase=IgnSteadyState;
					}
				break;
				}
			case IgnSteadyState:
				{
				GpioOutputSet(&DKGPowerSupply,true); //Ta linijka powinna byc wewnatrz if'a
				if(timer<=0)
					{
					//tu powinien byc DKG start
					timer=(U32)Tfce.value*1000;
					GetRegs()->Phase=FlameControllerStart;
					}
				break;
				}
			case FlameControllerStart:
				{
				if(timer<=0)
					{
					timer=(U32)Tpi.value*1000;
					GetRegs()->Phase=IgnitionWait;
					}
				break;
				}
			case IgnitionWait:
				{
				if(timer<=0)
					{
					noise_immunity=true;
					timer=(U32)Tign.value*1000;
					GetRegs()->Phase=Ignition;
					}
				break;
				}
			case Ignition:
				{
				if(timer<=0)
					{
					noise_immunity=false;
					pre_operation=true;
					timer=25*1000;
					GetRegs()->Phase=Operation;
					}
				break;
				}
			case Operation:
				{
				if(GetRegs()->BurnerFail)  //to powinno byc w ignition wait
					{
					GpioOutputSet(&ClearFail,true);
					timer=((U32)Tlr.value+2)*1000; //zapytac o magiczne +2
					GetRegs()->Phase=LockoutReset;
					Logging(log_path,buf,snprintf(buf,sizeof(buf),"Phase(0x%02X)\n",GetRegs()->Phase));
					}
				else if(GetRegs()->SolenoidValve1==false || (GetRegs()->SolenoidValve2==false && timer<=0))
					{
					SetFan(1000);
					GpioOutputSet(&DKGPowerSupply,false);
					timer=(U32)Tpef.value*1000;
					GetRegs()->Phase=PostExtinguishFlush;
					Logging(log_path,buf,snprintf(buf,sizeof(buf),"Phase(0x%02X)\n",GetRegs()->Phase));
					}
				else
					{
					U16 power_request=GetRegs()->PowerRequest;
					if(pre_operation)
						{
						power_request=0;
						//GetRegs()->PowerRequest=power_request; // trigger stop condition
						if(fan_set<=PWMmin.value)
							pre_operation=false;
						}
					else if(power_source==Analog)
						{
						power_request=GetRegs()->AnalogInput/10;
						GetRegs()->PowerRequest=power_request;
						}
					else if(power_source==Contact)
						{
						if(t-t_contact>=50)
							{
							t_contact=t;
							if(GetRegs()->ContactDrv1 && !GetRegs()->ContactDrv2)
								{
								if(power_request<1000)
									power_request++;
								}
							else if(!GetRegs()->ContactDrv1 && GetRegs()->ContactDrv2)
								{
								if(power_request>0)
									power_request--;
								}
							}
						GetRegs()->PowerRequest=power_request;
						}
					U32 value=PWMmin.value+(U32)power_request*(PWMmax.value-PWMmin.value)/1000;
					if(value>PWMmax.value)
						value=PWMmax.value;
					SetFan(value);
					}
				break;
				}
			case LockoutReset:
				{
				if(timer<=2000)
					GpioOutputSet(&ClearFail,false);
				if(timer<=0)
					{
					timer=(U32)Tpef.value*1000;
					GpioOutputSet(&DKGPowerSupply,false);
					GetRegs()->Phase=PostExtinguishFlush;
					}
				break;
				}
			case PostExtinguishFlush:
				{
				if(timer<=0)
					{
					SetFan(0);
					GetRegs()->FailNo++;
					GetRegs()->Phase=Stop;
					GetRegs()->PowerRequest=0;
					}
				break;
				}
			case PostStopFlush:
				{
				if(timer<=0)
					{
					SetFan(0);
					//GetRegs()->FailNo=0;
					GetRegs()->Phase=Stop;
					GetRegs()->PowerRequest=0;
					}
				break;
				}

			case LockoutExtinguish:
			case LockoutSafety:
			case LockoutFan:
				{
				GpioOutputSet(&Alarm,true);
				if(timer<=0)
					{
					SetFan(0);
					GpioOutputSet(&ClearFail,false);
					GpioOutputSet(&DKGPowerSupply,false);
					if(GetRegs()->ContactInput)
						{
						GetRegs()->FailNo=0;
						GetRegs()->Phase=Stop;
						GetRegs()->PowerRequest=0;
						Logging(log_path,buf,snprintf(buf,sizeof(buf),"Phase(0x%02X)\n",GetRegs()->Phase));
						}
					}
				break;
				}
			};

		if(Stop<GetRegs()->Phase && GetRegs()->Phase<LockoutExtinguish)
			{
			if(GetRegs()->PowerSupply==false)
				{
				timer=(U32)Tpef.value*1000;
				GetRegs()->Phase=LockoutSafety;
				Logging(log_path,buf,snprintf(buf,sizeof(buf),"Phase(0x%02X)\n",GetRegs()->Phase));
				}
			else if(GetRegs()->FailNo>=Nmax.value)
				{
				timer=(U32)Tpef.value*1000;
				GetRegs()->Phase=LockoutExtinguish;
				Logging(log_path,buf,snprintf(buf,sizeof(buf),"Phase(0x%02X), FailNo(%hu) >= Nmax(%hu)\n",GetRegs()->Phase,GetRegs()->FailNo,Nmax.value));
				}
			else if(GpioOutputIsActive(&Fan) && t-t_fan>=(U32)Tss.value*1000 && GetRegs()->Tacho<Fmin.value)
				{
				timer=(U32)Tpef.value*1000;
				GetRegs()->Phase=LockoutFan;
				Logging(log_path,buf,snprintf(buf,sizeof(buf),"Phase(0x%02X), Tacho(%hu) < Fmin(%hu)\n",GetRegs()->Phase,GetRegs()->Tacho,Fmin.value));
				}
			}

		if(FlameControllerStart<=GetRegs()->Phase && GetRegs()->Phase<LockoutReset)
			{
			if(((power_source==Analog || power_source==Contact) && GetRegs()->ContactStart==false) || \
				(power_source==RS485 && GetRegs()->PowerRequest==0))
				{
				SetFan(1000);
				GpioOutputSet(&DKGPowerSupply,false);
				timer=(U32)Tpsf.value*1000;
				GetRegs()->Phase=PostStopFlush;
				Logging(log_path,buf,snprintf(buf,sizeof(buf),"Phase(0x%02X), PowerSource(%hu)\n",GetRegs()->Phase,power_source));
				}
			}

		if(GetRegs()->Phase!=Stop)
			fan_set=FanProcess();

		GetRegs()->Fan           =GpioOutputIsActive(&Fan);
		GetRegs()->Alarm         =GpioOutputIsActive(&Alarm);
		GetRegs()->ClearFail     =GpioOutputIsActive(&ClearFail);
		GetRegs()->DKGPowerSupply=GpioOutputIsActive(&DKGPowerSupply);
		GetRegs()->PWM           =TIM3->CCR1;
		}
	osThreadTerminate(NULL);
	};

#ifdef USE_FULL_ASSERT

/**
 * @brief Reports the name of the source file and the source line number
 * where the assert_param error has occurred.
 * @param file: pointer to the source file name
 * @param line: assert_param error line source number
 * @retval None
 */
void assert_failed(uint8_t* file, uint32_t line)
	{
	/* User can add his own implementation to report the file name and line number,
	 ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
	while(1);
	}

#endif

