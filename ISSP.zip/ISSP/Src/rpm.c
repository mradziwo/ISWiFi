#include "app.h"
#include "rpm.h"

extern const U32 Tim2BaseFreq;
static tRpm Rpm;


U32 GetRevolutionFreq(void)
	{
	HAL_NVIC_DisableIRQ(TIM2_IRQn);
	U32 interval=Rpm.PulsesInterval;
	U32 no      =Rpm.PulsesNo;
	Rpm.PulsesInterval=0;
	Rpm.PulsesNo=0;
	HAL_NVIC_EnableIRQ(TIM2_IRQn);
	U32 f=0;
	if(interval) f=(U64)Tim2BaseFreq*no/interval;
	return f;
	};

void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
	{
	if(htim->Instance==TIM2)
		{
		U16 cc =__HAL_TIM_GET_COMPARE(htim,TIM_CHANNEL_1);
		U16 cnt=__HAL_TIM_GET_COUNTER(htim);

		U32 overflow=Rpm.Overflow;
		Rpm.Overflow=0;

		// capture overflow
		if(__HAL_TIM_GET_FLAG(htim, TIM_FLAG_CC1OF))
			{
			__HAL_TIM_CLEAR_IT(htim, TIM_FLAG_CC1OF);
			Rpm.Valid=false;
			Rpm.PulsesInterval=0;
			Rpm.PulsesNo=0;
			}

		// when update is not handled yet
		if(__HAL_TIM_GET_FLAG(htim, TIM_FLAG_UPDATE))
			{ // and happend before the capture
			if(cnt>=cc)
				{ // then handle it here
				__HAL_TIM_CLEAR_IT(htim, TIM_IT_UPDATE);
				overflow++;
				}
			}

		U16 d=cc-Rpm.CC;
		if(cc<Rpm.CC && overflow>0)
			overflow--;
		Rpm.CC=cc;

		if(Rpm.Valid)
			{
			Rpm.PulsesInterval+=(overflow<<16)+d;
			Rpm.PulsesNo++;
			}
		Rpm.Valid=true;
		}
	};

void Tim2PeriodElapsedCallback(TIM_HandleTypeDef *htim)
	{
	if(++Rpm.Overflow>2*(Tim2BaseFreq>>16)) // [s]
		{
		Rpm.Overflow--;
		Rpm.Valid=false;
		}
	};
