#ifndef INC_RPM_H_
#define INC_RPM_H_


typedef struct
	{
	U32 PulsesNo;
	U32 PulsesInterval;
	U32 Overflow;
	U16 CC;
	U8  Valid;
	}tRpm;

U32 GetRevolutionFreq(void);


#endif /* INC_RPM_H_ */
