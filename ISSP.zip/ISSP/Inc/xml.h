#ifndef SRC_XML_H_
#define SRC_XML_H_

#include <ff.h>
#include "yxml.h"
#include "app.h"

typedef struct
	{
	U16 min;
	U16 max;
	U16 def;
	U16 value;
	U16 version;
	}tXmlEntry;

typedef struct
	{
	yxml_t x;
	U8*  xstack;
	U32  stacksize;
	TCHAR* path;
	FIL  file;
	U8   buf[256];
	U16  index;
	UINT bytesread;
	char content[256];
	char* tree[8];
	U8   depth;
	}tXml;

U8 XmlInit(tXml** xml, TCHAR* path, U32 stacksize);
U8 XmlReset(tXml* xml);
U8 XmlClose(tXml** xml);
yxml_ret_t XmlGetObject(tXml* xml, char** object);
yxml_ret_t XmlFind(tXml* xml, char* tokens, U8 no);
U8 XmlReadEntry(tXml* xml, tXmlEntry* entry, char* tokens, U8 no);
U8 XmlWrite(tXml* xml, const TCHAR* path, char* tokens, U8 no, U16 value, char* format);

#endif /* SRC_XML_H_ */
