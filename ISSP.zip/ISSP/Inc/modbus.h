#ifndef MODBUS_H_
#define MODBUS_H_

#include "app.h"

enum ModbusState
	{
	State_Init = 0,
	State_Rx   = 1,
	State_Tx   = 2,
	};

enum ModbusFuncCode
	{
	ReadHoldingRegister    = 0x03,
	WriteSingleRegister    = 0x06,
	WriteMultipleRegisters = 0x10,
	};


typedef struct
	{
	U8  Address;
	U8  Function;
	U8  Data[252];
	U16 Crc;
	}tRtu;

ASSERT_SIZE(tRtu,256);

typedef U8 (*tSender)(U8* data, U8 size, U32 timeout);

typedef struct
	{
	tSender Sender;
	tRtu* Rtu;
	U32 Timeout;
	U32 Timestamp;
	U16 Crc;
	U8  Address;
	U8  State;
	U8  Len;
	U8  CrcByteNo;
	}tFrame;


U8 ModbusInit(tFrame* const self, tRtu* rtu, U8 address, U32 timeout, tSender sender);
U8 ModbusRxProcess(tFrame* const self, U8 data);
U8 ModbusTxProcess(tFrame* const self);

void ModbusSerialTask(void const* pvParameters);

#endif /* MODBUS_H_ */
