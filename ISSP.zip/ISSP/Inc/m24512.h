#ifndef M24512_H_
#define M24512_H_

#define M24512_SIZE     0x10000
#define M24512_BLK_SIZ  512
#define M24512_BLK_NBR  (M24512_SIZE/M24512_BLK_SIZ)


U8 M24512_Init(U8 lun);
U8 M24512_GetCapacity(U8 lun, U32* block_num, U16* block_size);
U8 M24512_IsReady(U8 lun);
U8 M24512_IsWriteProtected(U8 lun);
U8 M24512_Read (U8 lun, U8* buf, U32 blk_addr, U16 blk_len);
U8 M24512_Write(U8 lun, U8* buf, U32 blk_addr, U16 blk_len);
U8 M24512_GetMaxLun(void);


#endif /* M24512_H_ */
