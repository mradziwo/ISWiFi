#ifndef APP_H_
#define APP_H_

#include "stm32f1xx.h"
#include "stm32f1xx_hal_tim.h"

#define ARRAY_SIZE(array)           (sizeof(array)/sizeof(array[0]))
#define ASSERT(expression,comment)  typedef int comment[1-2*!(expression)]
#define ASSERT_SIZE(type,size)      ASSERT(sizeof(type)==size,ErrorSize_of_##type)

#define false 0
#define true  1

typedef uint64_t U64;
typedef  int64_t S64;

typedef uint32_t U32;
typedef  int32_t S32;

typedef uint16_t U16;
typedef  int16_t S16;

typedef  uint8_t  U8;
typedef   int8_t  S8;


typedef union
	{
	U8 u8;
	struct
		{
		U8 Pin    :1;
		U8 Por    :1;
		U8 Soft   :1;
		U8 IWdg   :1;
		U8 WWdg   :1;
		U8 LowPwr :1;
		};
	}tResetFlag;


U8   AppBackupValid(void);
U8   AppPowerFail(void);
void AppTimer(void);

U8   AppUsbConnected(void);
void AppUsbClbk(U8 connect);

U32  AppRS485RxError(void);

void Tim2PeriodElapsedCallback(TIM_HandleTypeDef *htim);

#endif /* APP_H_ */
