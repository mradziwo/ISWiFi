#ifndef VCP_H_
#define VCP_H_

#include "app.h"


void VcpRxEvent(U8* data, U32 size);

void VcpTask(void const* pvParameters);

#endif /* VCP_H_ */
