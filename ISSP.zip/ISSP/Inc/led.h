#ifndef LED_H_
#define LED_H_


typedef union
	{
	U16 u16;
	struct
		{
		U16 Out0  :1; // LSB
		U16 Out1  :1;
		U16 Out2  :1;
		U16 Out3  :1;
		U16 Out4  :1;
		U16 Out5  :1;
		U16 Out6  :1;
		U16 Out7  :1;
		U16 Out8  :1;
		U16 Out9  :1;
		U16 Out10 :1;
		U16 Out11 :1;
		U16 Out12 :1;
		U16 Out13 :1;
		U16 Out14 :1;
		U16 Out15 :1; // MSB
		};
	}tLedChip;

typedef union
	{
	U8 u8;
	struct
		{
		U8 A  :1;
		U8 B  :1;
		U8 C  :1;
		U8 D  :1;
		U8 E  :1;
		U8 F  :1;
		U8 G  :1;
		U8 DP :1;
		}Led;
	}tLed7Seg;

typedef union
	{
	tLedChip Chip;
	struct
		{
		tLed7Seg Seg;
		union
			{
			U8 u8;
			struct
				{
				U8 Led1  :1;
				U8 Led2  :1;
				U8 Led3  :1;
				U8 Led4  :1;
				U8 Led5  :1;
				U8 Led6  :1;
				U8 Led7  :1;
				U8 Led8  :1;
				}Group0;
			struct
				{
				U8 Led9  :1;
				U8 Led10 :1;
				U8 Led11 :1;
				U8 Led12 :1;
				U8 Led13 :1;
				U8 Led14 :1;
				U8 Led15 :1;
				U8 Led16 :1;
				}Group1;
			}Led;
		};
	}tLed;

ASSERT_SIZE(tLed,2);

U8 GetLed7SegCode(U8 v);

void LedInit(void);
void LedWrite(U8 segment, tLed* write);

void DisplayRefresh(U32 timestamp);

#endif /* LED_H_ */
