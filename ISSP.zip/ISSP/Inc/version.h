#define VER_MAJOR 0
#define VER_MINOR 0
#define VER_SVN   7
#define VER_MODS  false
