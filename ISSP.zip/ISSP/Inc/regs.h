#ifndef REGS_H_
#define REGS_H_

#include "app.h"

typedef enum
	{
	NormalMode,
	ServiceMode,
	FactoryMode,
	}tMode;

tMode GetMode(void);
void  SetMode(tMode mode);

typedef enum
	{
	Stop                 =0x00,
	PreFlush             =0x01,
	IgnSteadyState       =0x02,
	PostStopFlush        =0x05,
	PostExtinguishFlush  =0x06,
	FlameControllerStart =0x10,
	IgnitionWait         =0x11,
	Ignition             =0x12,
	Operation            =0x14,
	LockoutReset         =0x19,
	LockoutExtinguish    =0xE1,
	LockoutSafety        =0xE2,
	LockoutFan           =0xE4,
	Failure              =0xF1,
	}tPhase;

typedef enum
	{
	Analog,
	Contact,
	RS485,
	CAN,
	}tPowerSource;

typedef union
	{
	U16 Address[0x92];
	struct
		{
		U16 Reg_0;         // test purpose
		U16 FirmwareVer;
		U16 FirmwareRev;
		U16 HardwareVer;   // factory write
		U16 Id;            // factory write
		U16 ModbusAddr;    // normal write
		U16 RS485Baudrate; // normal write
		U16 UtcTimeL;      // normal write
		U16 UtcTimeH;      // normal write
		U16 UtcOffset;     // normal write
		U16 PowerSource;   // normal write
		U16 PWMmin;        // service write
		U16 PWMmax;        // service write
		U16 PWMstart;      // service write
		U16 Nmax;          // service write
		U16 Phase;
		U16 ContactInput;
		U16 ContactDrv1;
		U16 ContactDrv2;
		U16 ContactStart;
		U16 AnalogInput;
		U16 PowerSupply;
		U16 IgnitionTrafo; // Z
		U16 AuxBlower;     // M
		U16 SolenoidValve1;// V1
		U16 SolenoidValve2;// V2
		U16 BurnerFail;    // SA - External Lock Out
		U16 PowerFail;
		U16 ________________1Cto1F[4];
		U16 PowerRequest;  // normal write only when PowerSource is RS485
		U16 AnalogTemp;
		U16 DigitalTemp;
		U16 ________________23to2F[13];
		U16 Fan;           // service write
		U16 Alarm;         // service write
		U16 ClearFail;     // service write
		U16 DKGPowerSupply;// service write
		U16 ________________34to4F[28];
		U16 PWM;           // service write
		U16 Tacho;
		U16 ________________52to6F[30];
		U16 FailNo;        // normal write
		U16 FailHistory[33];
		};
	}tRegs;

ASSERT_SIZE(tRegs,0x92*sizeof(U16));

#define REG_ADDR(name) ((U16)(U32)(&((tRegs*)0)->name)/sizeof(U16))
#define REG_ADDR_SERVICE 0xA55A // service reg is outside the register map

void RegSetDefault(void);

tRegs* GetRegs(void);

U8 RegAddrValidation(U16 addr);
U8 RegWrite(U16 addr, U16 data);
U8 RegRead (U16 addr, U16* data);

U8 ServiceEvent(U16 data);
U8 RegWriteEvent(U16 addr, U16 data);
U8 RegReadEvent(U16 addr, U16* data);

#endif /* REGS_H_ */
