/*
 * config.c

 *
 *  Created on: 28 Jun 2017
 *      Author: CCM
 */

#include "config.h"
S16 getConfigControllerT0_1()
{
	return(15);
}
S16 getConfigControllerT0_2()
{
	return(15);
}
S16 getConfigControllerH_1()
{
	return(3);
}
S16 getConfigControllerH_2()
{
	return(3);
}
