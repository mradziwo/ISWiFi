/*
 * config.h
 *
 *  Created on: 28 Jun 2017
 *      Author: CCM
 */

#ifndef CONFIG_H_
#define CONFIG_H_
#include "app.h"
#include "common.h"

S16 getConfigControllerT0_1();
S16 getConfigControllerT0_2();
S16 getConfigControllerH_1();
S16 getConfigControllerH_2();



#endif /* CONFIG_H_ */
