/*
 * HysteresisController.h
 *
 *  Created on: 28 Jun 2017
 *      Author: CCM
 */

#ifndef HYSTERESISCONTROLLER_H_
#define HYSTERESISCONTROLLER_H_

#include "app.h"
#include "common.h"


void TempControllerTask(void const* pvParameters);
#endif /* HYSTERESISCONTROLLER_H_ */
