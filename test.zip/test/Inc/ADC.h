/*
 * ADC.h
 *
 *  Created on: 15 Jun 2017
 *      Author: CCM
 */

#ifndef ADC_H_
#define ADC_H_
void ADCTask(void const* pvParameters);


#endif /* ADC_H_ */
